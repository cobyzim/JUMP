package com.cognixia.jump.crudexercise.animalcrudexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimalCrudExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
