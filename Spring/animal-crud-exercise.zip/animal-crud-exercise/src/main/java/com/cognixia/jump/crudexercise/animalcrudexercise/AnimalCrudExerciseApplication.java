package com.cognixia.jump.crudexercise.animalcrudexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimalCrudExerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimalCrudExerciseApplication.class, args);
	}

}
