package com.cognixia.jump;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonToAddressApplicationTests {

	@Test
	void contextLoads() {
	}

}
