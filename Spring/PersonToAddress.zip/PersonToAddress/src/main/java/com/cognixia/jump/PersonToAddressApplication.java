package com.cognixia.jump;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonToAddressApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonToAddressApplication.class, args);
	}

}
