package com.cognixia.jump.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringInitializrDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
